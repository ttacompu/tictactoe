const Ingredients = ({name, ingredients}) =>
    <div>
        <h1>{name}</h1>
        <ul className='ingredients'>
            {ingredients.map((ingredient, i) =>
                <li key={i}>{ingredient.name}</li>
            )}
        </ul>

    </div>

export default Ingredients;


