import Recipe from './Recipe';


const Menu = ({ title, recipe }) =>
    <article>
        <header>
            <h1>{title}</h1>
        </header>
        <div className="recipes">
            {recipe.map((item, i) => <Recipe key={i} {...item} />)}
        </div>
        
    </article>

export default Menu;