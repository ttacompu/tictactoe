import Instructions from './Instructions';
import  Ingredients from './Ingredients';
import Summary from './Summary';

const Recipe = ({ name, ingredients, steps }) =>
    <section id={name.toLowerCase().replace(/ /g, '-')}>
        <Ingredients name={name} ingredients={ingredients}></Ingredients>
        <Instructions title="Cooking Instructions" steps={steps} ></Instructions>
        <Summary title={'summary of ' + name} ingredients={'ab'} steps={steps.length} ></Summary>
    </section>

export default Recipe;