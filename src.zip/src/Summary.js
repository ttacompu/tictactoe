const Summary = ({ ingredients, steps, title }) =>
    <div className="summary">
        <h1>{title}</h1>
        <p>
            <span>{ingredients} Ingredients</span> | <span>{steps} Steps</span>
        </p>
    </div>

Summary.propTyes ={ingredients: PropTypes.number.isRequired};

export default Summary