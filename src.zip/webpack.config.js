const path = require('path');
const webpack = require('webpack');
const HtmlwebpackPlugin = require('html-webpack-plugin');


module.exports = function (env) {
    let config = {
        context: path.resolve(__dirname, './src'),
        entry: {
            app: './app.js'
        },
        output: {
            filename: '[name].bundle.js',
            path: path.resolve(__dirname, './dist'),
            publicPath: '/'
        },
        devtool: 'inline-source-map',
        devServer: {
            port: 3000
        },
        resolve: {
            extensions: ['.js', '.css']
        },
        module: {
            rules: [
                {
                    test: /\.scss$/,
                    use: [{
                        loader: "style-loader" // creates style nodes from JS strings 
                    }, {
                        loader: "css-loader" // translates CSS into CommonJS 
                    }, {
                        loader: "sass-loader" // compiles Less to CSS 
                    }]
                },

                {
                    test: /\.js$/,
                    exclude: /node_modules/,
                    use: {
                        loader: 'babel-loader',
                        options: {
                            presets: ['env', 'react'],
                            plugins: ['transform-object-rest-spread']

                        }
                    }
                }
            ]
        },
        plugins: [
            new HtmlwebpackPlugin({
                template: 'index.html',
                inject: true
            }),

            new webpack.ProvidePlugin({
                'React': 'react',
                'ReactDOM': 'react-dom',
                'PropTypes': 'prop-types'
            })
        ]
    }

    return config;

}